1.在express中 get方式的请求如何获取浏览器发送的数据?
	
2.在express中post方式的请求如何获取浏览器发送的数据?
	
3. 在express中通过编写什么来区分浏览器发送的请求()
	A : exoress. Router ()       B：express.public()   
	C: express.redirect()        D：express.static()
	
4.（多选）node怎么运行当前目录下demo.js文件（）
	A：node  run  demo        B： node  demo
	C：node  demo.js          D:  node  install  demo

5.（多选）关于nodejs中可以暴露add函数的代码是() 
A: exports=add                  B: module.exports=add 
C: module.exports.add=add       D: exports.add=add
1. （多选） 下面使用npm 下载express框架语法正确的是（） 
 A：npm down express                   B：npm install express
 B：npm download express               D: npm install –g express
     
2. （多选）下面在express发送响应的语句正确的是（） 
A：res.end({“success”:”发送成功”})          B：res.send({“success”:”发送成功”})
C：res.end(‘{“success”:”发送成功”}’) 	   D：res.end(‘{“success”:”发送成功”}’)

3.在express中可以发送静态资源的中间件是（）
	A : exoress. Router ()       B：express.public()   
	C: express.redirect()        D：express.static()

4.express框架通过编写什么来区分浏览器发送的请求()
	A : exoress. Router ()       B：express.public()   
	C: express.redirect()       D：express.static()

5.请画出浏览器和服务器交互的示意图
//function fn(collection){ //collection 形参    ==》参数传入的
//	
//	// 把collection 形参    ==》函数内声明的
//	var collection="函数内声明的"
//	console.log(collection)
//}
//
//fn("参数传入的") // 实参 
//
//// 打印出什么    ==》"函数内声明的"


//var obj={
//	insert:function(){console.log("insert")},
//	update:function(){console.log("update")}
//}
//// 对象的取值 两种
//// obj.insert() // insert
////obj["insert"]() //  insert
//
//function fn(type){
//	console.log("asdfasdfas")
////	if(type=="insert"){ ....}
//	// type  字符串
//	obj[type]() // insert
//	
//}
//fn("insert")  // 

var insert =function{
	console.log(collection)
	
}

function fn(){
	
	var collection="asdfasdf"
}





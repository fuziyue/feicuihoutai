console.log("demo02.js中的代码");

console.log("运行js文件的目录");
console.log(__dir name);
console.log("运行js文件的位置（目录+文件的名称）");
console.log(__filename);

// 运行
// 1. 在当前目录下 打开cmd 命令行（ shift +鼠标右键 ）
// 2.  node demo02.js


// 怎么去 加载多个js文件呢？？？？
// 在 html  通过 script 加载的
// 在node 怎么弄???

// 模块化    解决  nodejs 中 怎么加载 多个js文件的 东西
// 怎么去模块化 ？？、
//  es5 没有 模块化的概念  
// 规范 ：commonjs  
// 规定了  js怎么去模块化


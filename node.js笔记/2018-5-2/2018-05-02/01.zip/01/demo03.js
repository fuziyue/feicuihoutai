// demo03.js

var text ="demo03中的内容 "

function fn(){
	console.log(text);
//	return "返回的内容"
}
// 函数的调用   没有返回值   undefined

// 定义模块
module.exports=fn; // 暴露的什么    就是  fn 函数



// 多个 怎么办？？？？
//  那个 东西 能放置多个内容     对象obj= {key:value}     对象取值  两种    obj.key  obj["key"]     
//                            数组 []                 数组取值     arr[索引]





// demo01.js

// 运行 demo01.js

console.log("js文件中的代码111111111111111  ")


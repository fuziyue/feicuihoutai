// demo05 

//  在demo05中暴露 一个对象  对象 有text属性   add方法

//console.log(module.exports)
//module.exports={
//	text:"这是 demo05中内容",
//	add:function(x,y){
//		return x+y;
//	}
//}

//module.exports==> {}
// 通过对象赋值的方式 写上

//module.exports.text="这是 demo05中内容";
//
//module.exports.add=function(x,y){
//		return x+y;
//	}

// nodejs 暴露方法（module.exports） 进行了简化

//var aa="111111";
//
//var bb=aa;
//
// bb ==？？  111111
// 
// bb="22222"
//
//bb==??? 22222
 
//var aa=module.exports={}
//// aa 具有 暴露的功能
//aa.text="这是简化后的 "

// node中默认执行的
//exports=module.exports={};
// exports 他就具有的暴露的功能

exports.text="node中简化的"

// 注意 不要进行直接赋值  
// exports="简化" // 不对的

// 多个 怎么办？？？？
//  那个 东西 能放置多个内容     对象obj= {key:value}     对象取值  两种    obj.key  obj["key"]     
//                            数组 []                 数组取值     arr[索引]

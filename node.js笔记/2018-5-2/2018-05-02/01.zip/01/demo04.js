// demo04.js


// 在demo04中 使用  demo03 中的内容
// 模块化  
// 思路：
// 1. 在demo03中  定义成模块                          module.exports=暴露的内容
// 2. 在 demo04中   加载  demo03 这个模块    require("加载模块的文件名称")

// require("加载模块的文件名称")
// 自己的模块==》 相对路径
//console.log(require("./demo03"))

var demo04=require("./demo03");

demo04();








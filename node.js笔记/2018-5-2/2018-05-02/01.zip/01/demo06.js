// demo06

// 在demo06中使用 demo05

//  demo05 暴露多个内容  对象

var obj=require("./demo05");

console.log(obj) // 对象
console.log(obj.text)

//console.log(obj.add(1,1))


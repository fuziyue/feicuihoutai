// 1. 加载http 模块
// 2. 在http模块上创建 服务 （服务器）        createServer
// 3. 设置端口号（监听端口号）    			listen
// 4. 编写处理的逻辑 （创建服务后的回调）   function(req,res)
var http=require("http");
http.createServer(function(req,res){ 
	// request 请求对象   response 响应对象
	// 返回的 状态吗 200 成功
  //res.writeHead("状态吗",{"content-type":"类型;charset=编码格式"})
	res.writeHead(200,{"content-type":"text/plain;charset=utf-8"})
	// 发送响应的  res.end 	
	res.end("你好世界！！！")
	
	// 通过fs读取内容   ==》设置 响应头 通过 res.end发送给 浏览器
	
}).listen(3000) // listen 监听  3000 端口号

// 1. 启动服务器   node 06http.js              06http.js==> js文件的名称
//   cmd 没有 效果  
// 2. 浏览器访问服务器    localhost:3000   ||  127.0.0.1:3000
//    localhost  ==》本机      《== 127.0.0.1 
//     3000   ==》 服务器 监听的端口

// 在同一局域网内==》 局域网地址  ==》怎么看 ipconfig   ==》 ipv4 局域网的地址   10.10.10.186
//  局域网内的访问地址： 10.10.10.186:3000
//                     局域网的地址:服务器监听的端口号 
// 注意 ： 端口号 只能使用一次  ，不能同时启动两个服务器 
//  退出 服务器   ctrl + c

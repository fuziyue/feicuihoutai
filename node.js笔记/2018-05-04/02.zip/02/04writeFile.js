// writeFile 写内容

// 1. 加载fs模块
// 2. 编写方法  
// 3. 写参数和回调
// 4. 写处理的逻辑 

var fs = require('fs');
// writeFile 方法
// 第一参数 写入文件的地址  默认当前目录      ./ ../ 
//                       如果当前写入的文件不存在 ==> 自动创建该文件
// 第二参数  写入的数据
// 第三参数   写数据的编码格式    utf-8
// 第四参数   回调函数 ==》 回调函数的参数  err ==》 失败的原因
//var text="我是通过node写入的内容";
//fs.writeFile("writeFile.txt",text,"utf-8",function(err){
//	// 失败的检测
//	if(err){
//		console.log("写入失败");
//		console.log(err)
//	}else{
//		console.log("写入成功")
//	}
//})

// 1. 在a.txt中写一句话
// 2. 读取a.txt中的内容（读取写入的这句话 ） 打印出来
// 写入
fs.writeFile("a.txt", "今天天气很好", "utf-8", function(err) {
	if(err) {
		console.log("写入失败");
		console.log(err)
	} else {
		console.log("写入成功")  // 写完了 在读
		// 读取
		fs.readFile("a.txt", "utf-8", function(err, data) {
			if(err) {
				console.log("读取失败");
				console.log(err)
			} else {
				console.log("读取成功")
				console.log(data)
			}
		})
	}
})


// 先读  在写 
// 写完啦在读
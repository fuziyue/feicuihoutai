// work.js

// 第一种
//module.exports={
//	add:function(x,y){
//		return x+y;
//	},
//	sub:function(x,y){
//		return x-y;
//	}
//}

// 第二种 
exports.add=function(x,y){
 	return x+y;
}
exports.sub=function(x,y){
	return x-y;
}

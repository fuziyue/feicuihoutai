// 删除文件的方法   unlink
var fs=require("fs");
// 第一参数   删除文件的地址  默认当前目录下
// 第二参数   回调 ==> 回调的参数  err  失败的原因
fs.unlink("a.txt",function(err){
	if(err){
		console.log("删除失败")
		console.log(err)
	}else{
		console.log("删除成功")
	}
})


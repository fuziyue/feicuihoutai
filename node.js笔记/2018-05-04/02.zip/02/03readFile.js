// fs模块  操作文件的模块  
// 1. 加载fs模块
// 2. 编写方法
// 3. 设置参数和回调 （ 设计者  设计的）
// 4. 在回调中 编写处理的逻辑

var fs = require("fs"); // 加载fs模块
// readFile 的方法
// 第一参数 读取的文件的地址     默认当前目录下  如果是其他目录怎么办  ./  ../
// 第二参数  读取文件的格式   utf-8   非必填项
// 第三参数 回调函数  ===》回调函数的参数   回调函数的第一参数   失败的原因  err
//  								     回调函数的第二参数    读取到的数据   data                              
//fs.readFile("进门考.txt", "utf-8", function(err, data) { // err， data 都是形参 表示意义
//	//	console.log("失败的原因");
//	//	console.log(err);  // null
//	//	console.log("读取到的数据");
//	//	console.log(data); // 具体的数据
//	// 失败的检测
//	console.log("异步读取")
//	if(err) { // 存在  不是 null   真
//		console.log("读取失败");
//		console.log(err);
//	} else { // 不存在    null   假
//		console.log("读取成功");
//		console.log(data);
//	}
//})
// readFile ==> 异步的
// node 推荐使用  异步的

// 同步 有   怎么写呢  
//  异步的方法后面 +Sync后缀
// readFile  ==>  readFileSync 同步的读取

// 参数会发生变化
// 1. 回调函数 没有了  
// 2. 结果 通过方法的 return 直接返回
// data 接收同步读取的数据
//var data = fs.readFileSync("01npm使用.js1", "utf-8");
//console.log("同步读取");
//console.log(data);


// 如果同步失败了  ==》 直接报错 ，后面代码 不会执行 


//js语句  try catch 语句    处理同步的错误的
try{
	// js的可能报错的代码 
	var data = fs.readFileSync("01npm使用.js1", "utf-8");
}catch(err){ // err ==> 报错后，那个错误 
	// 报错后执行的代码
	console.log("读取失败");
	console.log(err);
}
console.log("同步读取");
console.log(data);

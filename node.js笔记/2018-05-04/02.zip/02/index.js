// index.js 使用写的 模块

//1. 加载
var obj=require("./work")// 可以有后缀 也可以没有
// 2. 使用

console.log(obj.add(1,2))

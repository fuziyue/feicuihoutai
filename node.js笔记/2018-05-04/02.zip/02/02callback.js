// 回调函数   callback ==》 把 匿名函数function 当做参数传入的函数 

// jquery   ==》    $("btn").click(function(){})

// setTimeout(function(){}, 1000)


//  方法的设计者
// jquery的作者   ==》 设计 jquery的方法  ==》 设计api 
//  设置方法时  不知道使用者用来干什么  ==》 比如 ： 点击事件click 
//                                          定义一个回调函数 让使用者传入


// 方法的使用者
// jquery的使用者   ==》 使用  jquery的方法 ===》 使用api
//  按照 api 传入参数  ==》   回调函数

// 作为 方法的设计者  设计一个方法
// 处理字符串  ==》 处理之后 不知道 使用者 怎么去  使用处理后的字符串 ==》 定义一个回调函数

// str ==》 处理的字符串 
// callback ==》 使用时 传入的函数 
function setStr(str,callback){ // str，callback==>形参 ：表示意义 不表示具体内容
	// 处理字符串
	var newStr="fc"+str;
	// 在 callback中把处理后的 字符串 传出
	callback(newStr); 
}
// 作为使用者  使用
// 按照 设计者设计的  api（参数 ）传入
setStr("tianle",function(str){ // function 中定义一个形参  ： 接收 处理后的字符串 
	// str ==> 处理后的字符串
	console.log("使用者使用  setStr")
	console.log(str)
})












// 由 demo01.js  demo02.js   demo03.js  .....
// 共同 组成 增删改查的功能
// 说明书 ：告诉这个什么东西   怎么去用
//  json文件   ：  package.json  ==》  包的说明书

// npm  node中 包管理工具
// npm -v   查看 包管理工具的  版本号
// 管理着 nodejs中其他人写 功能

// 下载别人写的功能  express ==》快速开发 后台的


// package.js 
// 名称：
//  版本号：
//  包的依赖： 除了他本身的文件之外的文件 都叫依赖
//                      依赖是其他的包


包 下载   存放的服务器
下载的地址: 国外的服务器
下载的速度: 慢  很慢

怎么解决呢???
下载地址: 国内的服务???=> 有   淘宝镜像
淘宝镜像怎么用???
安装 
npm install -g cnpm --registry=https://registry.npm.taobao.org


install 安装 

-g   global全局

npm 和 cnpm 使用时   区别  : 只是名称 不一样
npm install  包名
cnpm install  包名 

express: 快速搭建后台的

下载  npm  install express
	 cnpm install express

步骤: 
1. 在桌面上创建一个文件夹
2. 在这个文件夹中 打开cmd命令行
3. 使用 npm 或cnpm 下载  express 
	
	下载  npm  install express
		或 cnpm install express

下载之后 这个文件夹中会出现 node_modules文件夹 

如果局部下载 之后 没有出现 node_modules文件夹
1. 使用npm  init 初始化 一个package.json文件 
2. 在去下载 npm install 包名 
包的下载或安装 
npm install  包名   ==> 本地下载    下载到  指定的文件夹中

npm install  -g 包名
npm install  包名  -g   ===>   加了 -g  全局下载==> 下载到  一个特定的文件夹中

区别: 使用的时候
本地下载   ===> 只能在本地的这个文件夹中使用
全局下载   ===> 可以在任意的文件夹使用 

查看下载的包
本地 :  npm list
全局 :  npm list -g

删除下载好的包  un ===> 取反
本地: npm uninstall 包名
全局: npm uninstall -g 包名  ||   npm uninstall 包名  -g 
(直接右键  ==>  删除 )

